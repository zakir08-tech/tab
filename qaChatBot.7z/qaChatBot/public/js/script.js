
var sendBttn = document.getElementById('sendBttn');
var textBox = document.getElementById('textBox');
var chatContainer = document.getElementById('chatContainer')
var user = {message:""};
var countClick = 0;

var arrayOfPossibleMessage = [
    {message:"hi",response:"Hello\nHow are you"},
    {message:"how are you?",response:"I am good."},
    {message:"what is your name?",response:"I am a chatbot."}
]

function sendMessage(userMessage){
    var messageElement = document.createElement('div');
    messageElement.style.textAlign = "left";
    messageElement.style.margin = "10px";
    messageElement.style.color = "white"

    //userMessage = userMessage.replace(/[^a-zA-Z0-9 ]/g, '').trim();
    messageElement.innerHTML = "<span>You: </span>"+
                                "<span>" +userMessage+ "</span>";

    chatContainer.appendChild(messageElement);
}

function chatbotResponse(userMessage){
    var chatbotMessage = "";
    userMessage = userMessage.replace(/[^a-zA-Z0-9 ]/g, '').trim();

    if(userMessage =="hi"){
        chatbotMessage = "The Rohit Sharma-led home team stands just six wickets away from taking an unassailable 1-0 lead in the two-match series against Bangladesh at the MA Chidambaram Stadium. The visitors did show some resilience in the second innings to reach 158 for four at the close of Day 3 on Saturday, before bad light resulted in early Stumps, but they still need a whopping 357 runs for the result to be in their favour.Bangladesh have never won chasing a score of 400 runs or more in a Test match in 20 previous instances, where only one ended in a draw. Moreover, India have never lost a Test match after setting a target of 500 runs or more, recording 22 wins in 56 such matches, while 28 ended in a draw. The odds are immensely stacked in favour of India, who also have never lost a Test match against Bangladesh in history.Rishabh Pant notched up an emotional sixth Test century, Shubman Gill continued his sublime form at No. 3 since turning things around in Vizag earlier this year, and the pair stitched a valiant 167-run stand for the fourth wicket, as India, overnight 81/3, took an aggressive call to declare their second innings at 287 for 4 for an overall lead of 514.";
    }else if(userMessage == "how are you"){
        chatbotMessage = "I am feeling owsome!";
    }else{
        chatbotMessage = "Sorry! didn't get your question.";
    }

    var messageElement = document.createElement('div');
    messageElement.style.textAlign = "left";
    messageElement.style.margin = "10px";
    messageElement.style.color = "white"
  
    messageElement.innerHTML = "<img src='./img/qa-chatbot.jpeg' style='float: left; margin: 13px;' class='rounded-circle img-thumbnail' width='35px'/>"+
                                "<div class='container p-3 my-3 bg-dark text-white'>"+
                                //"<span id='response_"+countClick+"' style='color: yellow'>" +chatbotMessage+ "</span></div>";
                                "<span id='response_"+countClick+"' style='color: yellow'></span></div>";

    chatContainer.appendChild(messageElement);
    typeWriter(chatbotMessage);
}

function typeWriter(chatbotMessage) {
    var i=0;
    if (i < chatbotMessage.length) {
      document.getElementById("response_"+countClick).innerHTML += chatbotMessage.charAt(i);
      i++;
      setTimeout(typeWriter, 50);
    }
  }

sendBttn.addEventListener('click',function(e){
    countClick++;
    var userMessage = textBox.value;
    if(userMessage ==""){
        alert('please type in a message')
    }else{
        let userMessageText = userMessage.trim();
        user.message = userMessageText;
        textBox.value = "";
        sendMessage(userMessageText);
        chatbotResponse(userMessageText);
    }
});